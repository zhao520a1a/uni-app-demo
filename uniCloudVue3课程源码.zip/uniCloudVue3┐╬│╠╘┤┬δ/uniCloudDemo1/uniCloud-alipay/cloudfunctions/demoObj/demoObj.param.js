getUser(1);
// addUser({name:"坤坤",age:"25",like:["唱","跳","rap"]});
// updateUser("671e32a86d54399a8451033a")
// removeUser("671e28d74b6f6298c436e1a0")
// demo();