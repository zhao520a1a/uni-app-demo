const db = uniCloud.database();
const dbCmd = db.command;
const dbJQL = uniCloud.databaseForJQL()


module.exports = {
	_before: function () { // 通用预处理器
		this.startTime = Date.now()
		this.params = {name:"咸虾米"};
		this.clientInfo = this.getClientInfo();		
		if(false){
			throw new Error("没有权限");
		}
	},
	async getUser({size=3}=params){	
		if(!isNaN(size)){
			size = Number(size)
		}else{
			return {errMsg:"参数格式有误，需要number类型"}
		}		
		let res = await dbJQL.collection("demo-user").limit(size).get();
		return res;
	},
	async addUser(params = {}){
		let res = await dbJQL.collection("demo-user").add(params)
		return res;
		console.log(res);
	},
	async updateUser(id=""){
		let res = await dbJQL.collection("demo-user").doc(id).update({
			like:["唱","跳","rap","篮球"]
		})
		console.log(res);		
	},
	async removeUser(id=""){
		let res = await dbJQL.collection("demo-user").doc(id).remove();
		console.log(res);
	},
	
	async demo(){
		
	},
	
	_after(error, result){
		if(error) {
		   throw error
		}
		
		// result.timeCost = Date.now() - this.startTime
		// result.author="咸虾米开发"
		return result;
	},
	
	async _timing(){		
		let username = "匿名"+ Math.random().toString(36).substring(3,9);
		let rdmage = Math.floor(Math.random() * (50 - 10 + 1)) + 10 + "";		
		let res = await dbJQL.collection("demo-user").add({
			name:username,
			age:rdmage
		})
		console.log(res);
		return res;
	}
	
}
