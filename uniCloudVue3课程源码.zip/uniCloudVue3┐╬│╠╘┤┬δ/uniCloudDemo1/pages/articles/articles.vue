<template>
	<view class="">
		<button @click="add">新增</button>
	</view>
</template>

<script setup>
const db = uniCloud.database();

const add= ()=>{
	db.collection("demo-articles").add({
		title:"标题333",
		content:"内容333"
	}).then(res=>{
		console.log(res);
	})
}


</script>

<style lang="scss" scoped>

</style>
