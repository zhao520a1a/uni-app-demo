<template>
	<view class="">
		<view class="item" v-for="(item,index) in listData" :key="item._id">
			<view>标题：{{item.title}}</view>
			<view>内容：{{item.content}}</view>
			<view>发布者：{{item?.user_id[0]?.nickname || "未命名"}}</view>
		</view>
	</view>
</template>

<script setup>
import { ref } from 'vue';
const db = uniCloud.database();
const listData = ref([])


const getData = async()=>{
	try{
			
		let artTemp = db.collection("demo-articles")
		// .where(`user_id == $cloudEnv_uid`)
		.where(`status == true`)
		.getTemp();
		let userTemp =  db.collection("uni-id-users").field("username,nickname,_id").getTemp();
		let {result:{data}} = await db.collection(artTemp,userTemp).get();
		listData.value = data;
		console.log(data);
	}catch(err){
		uni.showModal({
			title:err.message,
			showCancel:false
		})
	}
}
getData();

</script>

<style lang="scss" scoped>
.item{
	padding:30rpx;
	border-bottom:1px solid #ccc;
}
</style>
