<template>
	<view class="">
		<uni-file-picker 
			ref="file"
			v-model="imageValue" 			
			mode="grid"
			limit="6"			
			:auto-upload="false"
		/>		
		<button @click="onSubmit">上传</button>
	</view>
</template>

<script setup>
import { ref } from 'vue';
const imageValue = ref([])
const file = ref(null);

const onProgress = (e)=>{
	console.log(e);
}

const onSubmit = ()=>{
	file.value.upload()
}
</script>

<style lang="scss" scoped>

</style>
