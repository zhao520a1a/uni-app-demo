<template>
	<view class="layout">
		<input v-model="formData.name" placeholder="请输入姓名"/>
		<input v-model="formData.age" placeholder="请输入年龄"/>
		<button @click="handleUpdate">修改</button>
	</view>
</template>

<script setup>
import { ref } from 'vue';
import {onLoad} from "@dcloudio/uni-app"
let id;
const db = uniCloud.database();
const formData = ref({
	name:"",
	age:""
})

onLoad((e)=>{
	id = e.id;
	getData();
})


const getData = async ()=>{
	let {result:{data}} = await db.collection("demo-user").doc(id).get({getOne:true})
	console.log(data);
	formData.value.name = data.name;
	formData.value.age = data.age;
	
}

const handleUpdate = async ()=>{
	let res = await db.collection("demo-user").doc(id).update(formData.value)
	console.log(res);
}
</script>

<style lang="scss" scoped>
.layout{
	padding:30rpx;
	input{
		border:1px solid #eee;
		margin-bottom: 30rpx;
		height: 80rpx;
		padding:0 20rpx;
	}
	
}
</style>
