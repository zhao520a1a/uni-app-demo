<template>
	<view class="">
		
		<button @click="handleAddUser">新增用户</button>
		
		<view class="item" v-for="item in dataList" :key="item._id">
			<view>{{item.name}}</view>
			<view>{{item.age}}</view>
			<view>-------</view>
		</view>
	</view>
</template>

<script setup>
import { ref } from 'vue';

const demoObj = uniCloud.importObject("demoObj");
const dataList = ref([])

const getData = async()=>{
	let {data} = await demoObj.getUser(7);
	dataList.value = data;
	console.log(data);
}


const handleAddUser = async()=>{
	let res = await demoObj.addUser({name:"小黑",age:"22",gender:1});
	console.log(res);
}

getData();





</script>

<style lang="scss" scoped>

</style>
